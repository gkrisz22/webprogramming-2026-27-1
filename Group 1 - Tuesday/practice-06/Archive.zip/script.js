const canvas = document.querySelector("canvas");
const ctx = canvas.getContext("2d");

const state = {
    box: {
        x: 0,
        y: 250,
        w: 40,
        h: 40,
        vx: 0.1
    }
};

// dt = delta time
function update(dt) {
    if (dt > 100) {
        return;
    }

    state.box.x += state.box.vx * dt;
    if (state.box.x > canvas.width) {
        state.box.x = 0;
    }
}

function draw() {

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "tomato"; //
    ctx.fillRect(state.box.x, state.box.y, state.box.w, state.box.h);
}


let last = performance.now();
function gameLoop() {
    const now = performance.now();
    const dt = now - last;
    last = now;

    update(dt);
    draw();

    requestAnimationFrame(gameLoop);
}

requestAnimationFrame(gameLoop);

/*
[1] - List things
[2] - Add some things

while(true) {
    
    if(you wrote exit) {
        exit(0);
    }
}
*/